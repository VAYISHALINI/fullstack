package com.yoga.vayishaa.enumerated;

public enum Role {
  USER,ADMIN
}
