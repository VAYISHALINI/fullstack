package com.yoga.vayishaa.dto.request;



import lombok.Data;

@Data
public class CourseRequest {
   

 
   private String duration;
   
    private String institution;
    private String image;
    private String course_name;
     private String description;
    
}
