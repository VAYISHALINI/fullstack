package com.yoga.vayishaa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VayishaaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VayishaaApplication.class, args);
	}

}
